This is local AI text-to-speech run with piper text to speech and ollama runs AI locally by using python from scratch (streaming response, not create .wav file. You can change command if you want)..
Attention (For educational purposes only): 
+ Remember to install aplay, refer to and piper github link 
Refer link: https://www.geeksforgeeks.org/linux-unix/aplay-command-in-linux-with-examples/
+ Put both file: .onnx and .json to models folder. Ex.: en_US-hfc_female-medium.onnx and en_US-hfc_female-medium.onnx.json.
+ From python version 3.10 or above: create virtual environment is different. Please refer to this link: https://docs.python.org/3.10/library/venv.html (Because this project runs python3.10, change this number base on your python version)
+ If you have this error: bad interpreter no such file or directory while running venv, refer to this link https://superuser.com/questions/1380418/python3-7-bad-interpreter-no-such-file-or-directory
Try to uninstall and reinstall it.
+ Run pip3 install -r requirements.txt to install python dependencies (If you're using python3 in linux)
+ Create a virtual environment for this project follow this path: Ex.: ~/Projects/python/.venv or you will have to choose your own path in file piper_tts.py to make it work.
+ To run project: python3 /path/to/your/file/main.py
+ Piper github: https://github.com/rhasspy/piper
+ Ollama Installation and Run AI locally: Just search google for that.
+ My code is very messy so you can change it if you want.
+ Only support Linux x86_64 now. I did not test in other operating system.