import asyncio
import ollama

from ollama import AsyncClient

model_name = "Your AI model name"

class Ollama_Ai:
    def __init__(self):
        self.answer_temp = ""

    def get_answer_temp(self):
        return self.answer_temp

    # Async ollama
    def ai_chat_handling(self, user_question):
        if not user_question:
            user_question = "Hello. Introduce your self."

        async def chat():
            answer_temp = ""
            message = {'role': 'user', 'content': f'{user_question}'}
            async for part in await AsyncClient().chat(model=model_name, messages=[message], stream=True):
                answer = part['message']['content']
                print(answer, end='', flush=True)
                self.answer_temp += answer
        try:
            asyncio.run(chat())
        except ollama.ResponseError as e:
            print('Error:', e.error)
            if e.status_code == 404:
                ollama.pull(model)
