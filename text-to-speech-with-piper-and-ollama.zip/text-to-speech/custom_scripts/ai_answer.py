class Ai_Answer:
    def __init__(self):
        self.ai_answer = ""

    # Getter va Setter
    def get_ai_answer(self):
        return self.ai_answer
    def set_ai_answer(self, x):
        self.ai_answer=x

