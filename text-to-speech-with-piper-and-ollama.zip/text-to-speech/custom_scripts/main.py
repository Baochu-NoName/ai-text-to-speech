import piper_tts
import ollama_ai
import ai_answer

user_question = input("Nhập câu hỏi của bạn cho AI: ")

ollama_models = ollama_ai.Ollama_Ai()
ai_obj = ai_answer.Ai_Answer()

ollama_models.ai_chat_handling(user_question)
ai_obj.set_ai_answer(ollama_models.get_answer_temp())
get_ollama_ai_answer = ai_obj.get_ai_answer()

# Remove \n and *
char_remove = ['\n', '*']
for char in char_remove:
    get_ollama_ai_answer = get_ollama_ai_answer.replace(char, "")

# Convert ai answer to speech
pipe_tts_module = piper_tts.Pipe_TTS().convert_text_to_speech(get_ollama_ai_answer)

print(pipe_tts_module)
if __name__ == "main":
    pip_tts_module
