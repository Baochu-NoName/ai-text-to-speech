import subprocess
import os  

def file_not_existed(file_path):
    if not os.path.exists(file_path):
        print("Path of the file is Invalid")
    else:
        print("Valid.")

class Pipe_TTS:

    def convert_text_to_speech(self, ai_answer):
        input_sentence = ai_answer
        piper_env_path = f"~/Projects/python/.venv/bin/piper"
        models_path = f"../models"

        file_not_existed(piper_env_path)
        file_not_existed(models_path)

        command = f"echo '{input_sentence}' | {piper_env_path} --model {models_path}/vi_VN-vais1000-medium.onnx --output-raw | aplay -r 22050 -f S16_LE -t raw -"
        try: 
            piper_tts = subprocess.run(command, shell=True, capture_output=True)
            print(piper_tts)
        except subprocess.CalledProcessError as e: 
            print(f"Command failed with return code: {e.returncode}")
      
